﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Level_Calculator
{
    class ItemNeeded
    {
        public string Name { get; set; }
        public int Number { get; set; }
    }
}
