﻿namespace Level_Calculator
{
    partial class PresetCheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.presetDropDown = new System.Windows.Forms.ComboBox();
            this.continueButton = new System.Windows.Forms.Button();
            this.editPresetButton = new System.Windows.Forms.Button();
            this.newPresetButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(73, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select an existing preset:";
            // 
            // presetDropDown
            // 
            this.presetDropDown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.presetDropDown.FormattingEnabled = true;
            this.presetDropDown.Items.AddRange(new object[] {
            "---"});
            this.presetDropDown.Location = new System.Drawing.Point(82, 38);
            this.presetDropDown.Name = "presetDropDown";
            this.presetDropDown.Size = new System.Drawing.Size(161, 26);
            this.presetDropDown.TabIndex = 2;
            // 
            // continueButton
            // 
            this.continueButton.ForeColor = System.Drawing.Color.Black;
            this.continueButton.Location = new System.Drawing.Point(233, 174);
            this.continueButton.Name = "continueButton";
            this.continueButton.Size = new System.Drawing.Size(80, 44);
            this.continueButton.TabIndex = 6;
            this.continueButton.Text = "Continue";
            this.continueButton.UseVisualStyleBackColor = true;
            this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
            // 
            // editPresetButton
            // 
            this.editPresetButton.ForeColor = System.Drawing.Color.Black;
            this.editPresetButton.Location = new System.Drawing.Point(123, 174);
            this.editPresetButton.Name = "editPresetButton";
            this.editPresetButton.Size = new System.Drawing.Size(80, 44);
            this.editPresetButton.TabIndex = 7;
            this.editPresetButton.Text = "Edit";
            this.editPresetButton.UseVisualStyleBackColor = true;
            this.editPresetButton.Click += new System.EventHandler(this.editPresetButton_Click);
            // 
            // newPresetButton
            // 
            this.newPresetButton.ForeColor = System.Drawing.Color.Black;
            this.newPresetButton.Location = new System.Drawing.Point(12, 174);
            this.newPresetButton.Name = "newPresetButton";
            this.newPresetButton.Size = new System.Drawing.Size(80, 44);
            this.newPresetButton.TabIndex = 8;
            this.newPresetButton.Text = "New";
            this.newPresetButton.UseVisualStyleBackColor = true;
            this.newPresetButton.Click += new System.EventHandler(this.newPresetButton_Click);
            // 
            // PresetCheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(325, 230);
            this.Controls.Add(this.newPresetButton);
            this.Controls.Add(this.editPresetButton);
            this.Controls.Add(this.continueButton);
            this.Controls.Add(this.presetDropDown);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Yellow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PresetCheck";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Preset Check";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox presetDropDown;
        private System.Windows.Forms.Button continueButton;
        private System.Windows.Forms.Button editPresetButton;
        private System.Windows.Forms.Button newPresetButton;
    }
}