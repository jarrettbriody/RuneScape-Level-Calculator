﻿namespace Level_Calculator
{
    partial class CustomInputForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startTier = new System.Windows.Forms.TextBox();
            this.endTier = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tierName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.addTierButton = new System.Windows.Forms.Button();
            this.finishTiersButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tierXP = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.itemList = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // startTier
            // 
            this.startTier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startTier.Location = new System.Drawing.Point(34, 26);
            this.startTier.Name = "startTier";
            this.startTier.Size = new System.Drawing.Size(130, 26);
            this.startTier.TabIndex = 0;
            // 
            // endTier
            // 
            this.endTier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endTier.Location = new System.Drawing.Point(198, 26);
            this.endTier.Name = "endTier";
            this.endTier.Size = new System.Drawing.Size(130, 26);
            this.endTier.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Level to Start Tier:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(200, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Level to End Tier:";
            // 
            // tierName
            // 
            this.tierName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tierName.Location = new System.Drawing.Point(34, 76);
            this.tierName.Name = "tierName";
            this.tierName.Size = new System.Drawing.Size(130, 26);
            this.tierName.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Name of Tier:";
            // 
            // addTierButton
            // 
            this.addTierButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addTierButton.ForeColor = System.Drawing.Color.Black;
            this.addTierButton.Location = new System.Drawing.Point(34, 257);
            this.addTierButton.Name = "addTierButton";
            this.addTierButton.Size = new System.Drawing.Size(130, 34);
            this.addTierButton.TabIndex = 8;
            this.addTierButton.Text = "Add New Tier";
            this.addTierButton.UseVisualStyleBackColor = true;
            this.addTierButton.Click += new System.EventHandler(this.addTierButton_Click);
            // 
            // finishTiersButton
            // 
            this.finishTiersButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.finishTiersButton.ForeColor = System.Drawing.Color.Black;
            this.finishTiersButton.Location = new System.Drawing.Point(198, 257);
            this.finishTiersButton.Name = "finishTiersButton";
            this.finishTiersButton.Size = new System.Drawing.Size(130, 34);
            this.finishTiersButton.TabIndex = 9;
            this.finishTiersButton.Text = "Finish";
            this.finishTiersButton.UseVisualStyleBackColor = true;
            this.finishTiersButton.Click += new System.EventHandler(this.finishTiersButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(209, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "XP Given per:";
            // 
            // tierXP
            // 
            this.tierXP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tierXP.Location = new System.Drawing.Point(198, 76);
            this.tierXP.Name = "tierXP";
            this.tierXP.Size = new System.Drawing.Size(130, 26);
            this.tierXP.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(19, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(325, 60);
            this.label6.TabIndex = 11;
            this.label6.Text = "Items needed\r\n(separate item name and number of\r\nitems with a single equal sign):" +
    "";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // itemList
            // 
            this.itemList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemList.Location = new System.Drawing.Point(34, 170);
            this.itemList.Multiline = true;
            this.itemList.Name = "itemList";
            this.itemList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.itemList.Size = new System.Drawing.Size(294, 78);
            this.itemList.TabIndex = 6;
            // 
            // CustomInputForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(362, 300);
            this.Controls.Add(this.itemList);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tierXP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.finishTiersButton);
            this.Controls.Add(this.addTierButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tierName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.endTier);
            this.Controls.Add(this.startTier);
            this.ForeColor = System.Drawing.Color.Yellow;
            this.Name = "CustomInputForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Custom Input";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox startTier;
        private System.Windows.Forms.TextBox endTier;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tierName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button addTierButton;
        private System.Windows.Forms.Button finishTiersButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tierXP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox itemList;
    }
}