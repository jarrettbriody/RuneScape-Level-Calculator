﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Level_Calculator
{
    class DictionaryValues
    {
        public double XpVal { get; set; }
        private Queue queue;

        public Queue Items
        {
            get { return queue; }
            set { queue = value; }
        }

        public int Start { get; set; }
        public int End { get; set; }
    }
}
