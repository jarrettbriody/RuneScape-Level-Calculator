﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Level_Calculator
{
    public partial class Form1 : Form
    {
        Skills skill;
        //
        int currentLevelVal;
        int currentXPVal;
        int targetLevelVal;
        bool otherItemsNeeded;
        public string SelectedSkill { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            skill = new Level_Calculator.Skills();
            string currentLevelValStr = currentLevel.Text;
            string currentXPValStr = currentXP.Text;
            string targetLevelValStr = targetLevel.Text;

            bool currentLevelValStrTryParse = int.TryParse(currentLevelValStr, out currentLevelVal);
            bool currentXPValTryParse = int.TryParse(currentXPValStr, out currentXPVal);
            bool targetLevelValTryParse = int.TryParse(targetLevelValStr, out targetLevelVal);
            
            output.Text = "";
            
            if(selectedSkill.Text != "")
            {
                if (currentLevelValStrTryParse == true && currentLevelVal >= 1 && currentLevelVal <= 99)
                {
                    if (currentXPValTryParse == true && currentXPVal >= 0 && currentXPVal <= 200000000)
                    {
                        if (targetLevelValTryParse == true && targetLevelVal >= 1 && targetLevelVal <= 99)
                        {
                            if (targetLevelVal - currentLevelVal >= 0 && skill.level[targetLevelVal - 1] - currentXPVal >= 0 && currentXPVal >= skill.level[currentLevelVal - 1] && currentXPVal < skill.level[currentLevelVal])
                            {
                                targetXP.Text = skill.level[targetLevelVal - 1].ToString();
                                GetResults();
                            }
                            else
                            {
                                output.Text += "Enter valid level and XP numerals.";
                            }
                        }
                        else
                        {
                            output.Text += "Enter a valid target level.\r\n";
                        }
                    }
                    else
                    {
                        output.Text += "Enter a valid current XP.\r\n";
                        if (targetLevelValTryParse == false || targetLevelVal < 1 || targetLevelVal > 99)
                        {
                            output.Text += "Enter a valid target level.\r\n";
                        }
                    }
                }
                else
                {
                    output.Text += "Enter a valid current level.\r\n";
                    if (currentXPValTryParse == false || currentXPVal < 0 || currentXPVal > 200000000)
                    {
                        output.Text += "Enter a valid current XP.\r\n";
                    }
                    if (targetLevelValTryParse == false || targetLevelVal < 1 || targetLevelVal > 99)
                    {
                        output.Text += "Enter a valid target level.\r\n";
                    }
                }
            }
            else
            {
                output.Text += "Select a skill.\r\n";
                if(currentLevelValStrTryParse == false || currentLevelVal < 1 || currentLevelVal > 99)
                {
                    output.Text += "Enter a valid current level.\r\n";
                }
                if (currentXPValTryParse == false || currentXPVal < 0 || currentXPVal > 200000000)
                {
                    output.Text += "Enter a valid current XP.\r\n";
                }
                if (targetLevelValTryParse == false || targetLevelVal < 1 || targetLevelVal > 99)
                {
                    output.Text += "Enter a valid target level.\r\n";
                }
            }
        }

        public void GetResults()
        {
            SelectedSkill = selectedSkill.Text;
            if (custom.Checked)
            {
                HandlePresets();
            }
            else
            {
                if (!File.Exists("..\\presets\\default.txt"))
                {
                    output.Text = "ERROR: Default preset has been removed.";
                    return;
                }
                else
                    skill.Path = "..\\presets\\default.txt";
            }
            output.Text = skill.Custom(SelectedSkill, currentLevelVal, currentXPVal, targetLevelVal, otherItemsNeeded);
        }

        public void HandlePresets()
        {
            this.Visible = false;
            MessageBox.Show("Instructions:\n\nSelect an existing preset to use or enter the name of a new preset you would like to create. If you would like to edit a preset, simply type the name of the preset in and continue.");
            PresetCheck preset = new PresetCheck();
            preset.ShowDialog();
            skill.Path = preset.PresetName;
            if (preset.PresetName != null)
            {
                if (preset.ExistingPreset == false)
                {
                    using (StreamWriter writer = new StreamWriter(preset.PresetName, true))
                    {
                        writer.Write("");
                    }
                    CustomInputForm custom = new CustomInputForm(preset.PresetName, selectedSkill.Text);
                    MessageBox.Show("Instructions:\n\nWhen using the custom editor, you must add tiers such that it spans from the level you will start to the level that you will stop. For example, you might woodcut regular logs from level 1 to level 15, stopping as soon as you hit 15. The next tier will be level 15 to level 30 and so on, with the last end and next start levels overlapping.");
                    switch (SelectedSkill)
                    {
                        case "Agility":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Attack":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Construction":
                            otherItemsNeeded = true;
                            break;
                        case "Cooking":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Crafting":
                            otherItemsNeeded = true;
                            break;
                        case "Defence":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Farming":
                            otherItemsNeeded = true;
                            break;
                        case "Firemaking":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Fishing":
                            otherItemsNeeded = true;
                            break;
                        case "Fletching":
                            otherItemsNeeded = true;
                            break;
                        case "Herblore":
                            otherItemsNeeded = true;
                            break;
                        case "Hitpoints":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Hunter":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Magic":
                            otherItemsNeeded = true;
                            break;
                        case "Mining":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Prayer":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Ranged":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Runecraft":
                            custom.EnableItemsNeeded = false;
                            otherItemsNeeded = false;
                            break;
                        case "Slayer":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Smithing":
                            otherItemsNeeded = true;
                            break;
                        case "Strength":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Thieving":
                            custom.EnableItemsNeeded = false;
                            break;
                        case "Woodcutting":
                            custom.EnableItemsNeeded = false;
                            break;
                        default:
                            break;
                    }
                    custom.ShowDialog();

                }
                else
                {
                    switch (SelectedSkill)
                    {
                        case "Construction":
                            otherItemsNeeded = true;
                            break;
                        case "Crafting":
                            otherItemsNeeded = true;
                            break;
                        case "Farming":
                            otherItemsNeeded = true;
                            break;
                        case "Fishing":
                            otherItemsNeeded = true;
                            break;
                        case "Fletching":
                            otherItemsNeeded = true;
                            break;
                        case "Herblore":
                            otherItemsNeeded = true;
                            break;
                        case "Magic":
                            otherItemsNeeded = true;
                            break;
                        case "Smithing":
                            otherItemsNeeded = true;
                            break;
                        default:
                            break;
                    }
                }
            }
            this.Visible = true;
        }
    }
}
