﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * Jarrett Briody
 * IGME 106 03
 * Queue class, inherits from IQueue interface
 * Enqueues and dequeues strings in a list
 */
namespace Level_Calculator
{
    class Queue
    {
        //list of words
        List<ItemNeeded> queueOfNames = new List<ItemNeeded>();

        //dequeue a word, removing from the front of the list
        public ItemNeeded Dequeue()
        {
            if(IsEmpty() == false)
            {
                ItemNeeded itemToBeReturned = queueOfNames[0];
                queueOfNames.RemoveAt(0);
                return itemToBeReturned;
            }
            throw new InsufficientExecutionStackException();
        }

        //enqueue a word by adding it to the end of the list
        public void Enqueue(ItemNeeded item)
        {
            queueOfNames.Add(item);
        }

        //check if the queue is empty or not
        public bool IsEmpty()
        {
            if(queueOfNames.Count == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Clear()
        {
            queueOfNames.Clear();
        }
    }
}
