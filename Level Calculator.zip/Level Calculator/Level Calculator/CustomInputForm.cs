﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Level_Calculator
{
    public partial class CustomInputForm : Form
    {
        public string SelectedSkill { get; set; }
        public string Path { get; set; }        
        public bool EnableItemsNeeded
        {
            get
            {
                if(itemName.Enabled && itemsNeeded.Enabled)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                itemName.Enabled = value;
                itemsNeeded.Enabled = value;
            }
        }

        public CustomInputForm(string path, string skill)
        {
            InitializeComponent();
            SelectedSkill = skill;
            Path = path;
            if(!File.Exists(Path))
            {
                using (var writer = new StreamWriter(Path,true))
                {
                    writer.WriteLine(SelectedSkill);
                }
            }
            else
            {
                string allText;
                using (var reader = new StreamReader(Path,true))
                {
                    allText = reader.ReadToEnd();
                    if (!allText.Contains(SelectedSkill))
                    {
                        reader.Close();
                        using(var writer2 = new StreamWriter(Path, true))
                        {
                            writer2.WriteLine(SelectedSkill);
                        }
                    }
                    else
                    {
                        reader.BaseStream.Position = 0;
                        List<string> strList = new List<string>();
                        string line;
                        bool inSkill = false;
                        while ((line = reader.ReadLine()) != null)
                        {
                            if(line == SelectedSkill)
                            {
                                inSkill = true;
                            }
                            if(inSkill)
                            {
                                if(line == "")
                                {
                                    inSkill = false;
                                }
                            }
                            else
                            {
                                strList.Add(line);
                            }
                        }
                        reader.Close();
                        using (var writer = new StreamWriter(Path))
                        {
                            foreach (var item in strList)
                            {
                                writer.WriteLine(item);
                            }
                            writer.WriteLine(SelectedSkill);
                        }
                    }
                }
            }
        }

        private void addTierButton_Click(object sender, EventArgs e)
        {
            bool close = false;
            try
            {
                double num = double.Parse(tierXP.Text);
            }
            catch (Exception)
            {
                tierXP.Text = "Error: NaN";
                close = true;
            }
            try
            {
                double num = double.Parse(startTier.Text);
            }
            catch (Exception)
            {
                startTier.Text = "Error: NaN";
                close = true;
            }
            try
            {
                double num = double.Parse(endTier.Text);
            }
            catch (Exception)
            {
                endTier.Text = "Error: NaN";
                close = true;
            }
            if (close)
            {
                return;
            }
            using (var writer = new StreamWriter(Path, true))
            {
                if(EnableItemsNeeded)
                {
                    string line = "[" + tierName.Text + ", " + tierXP.Text + ", " + startTier.Text + ", " + endTier.Text;
                    string allItems = itemName.Text;
                    string allItemNumbers = itemsNeeded.Text;
                    string[] itemNames = allItems.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
                    string[] itemNumbers = allItemNumbers.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
                    if(itemNames.Length == itemNumbers.Length)
                    {
                        for (int i = 0; i < itemNames.Length; i++)
                        {
                            line += ", " + itemNames[i] + "=" + itemNumbers[i];
                        }
                        line += "]";
                    }
                    writer.WriteLine(line);
                }
                else
                    writer.WriteLine("[" + tierName.Text + ", " + tierXP.Text + ", " + startTier.Text + ", " + endTier.Text + "]");
            }
            tierName.Text = "";
            tierXP.Text = "";
            if (endTier.Text != "99") startTier.Text = endTier.Text;
            else startTier.Text = "";
            endTier.Text = "";
            itemName.Text = "";
            itemsNeeded.Text = "";
            this.ProcessTabKey(true);
            this.ProcessTabKey(true);
            this.ProcessTabKey(true);
        }

        private void finishTiersButton_Click(object sender, EventArgs e)
        {
            using (var writer = new StreamWriter(Path, true))
            {
                writer.WriteLine();
            }
            this.Close();
        }
    }
}
