﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Level_Calculator
{
    public partial class CustomInputForm : Form
    {
        public string SelectedSkill { get; set; }
        public string Path { get; set; }    
        
        //property for checking if items are enabled or not
        public bool EnableItemsNeeded
        {
            get
            {
                return itemList.Enabled;
            }
            set
            {
                itemList.Enabled = value;
                //itemsNeeded.Enabled = value;
            }
        }

        public CustomInputForm(string path, string skill)
        {
            InitializeComponent();
            //pull in the skill and path requested
            SelectedSkill = skill;
            Path = path;

            //if the file doesn't yet exist then create one with the skill keyword at the top
            if(!File.Exists(Path))
            {
                using (var writer = new StreamWriter(Path,true))
                {
                    writer.WriteLine(SelectedSkill);
                }
            }

            //if the file exists
            else
            {
                string allText;
                //read in all the text in the file
                using (var reader = new StreamReader(Path,true))
                {
                    allText = reader.ReadToEnd();

                    //if that text does not contain the current skill's keyword
                    if (!allText.Contains(SelectedSkill))
                    {
                        //close the current reader and begin writing, start with writing the current skill keyword
                        reader.Close();
                        using(var writer2 = new StreamWriter(Path, true))
                        {
                            writer2.WriteLine(SelectedSkill);
                        }
                    }

                    //if that text does contain the current skill's keyword
                    else
                    {
                        //reset reader position
                        reader.BaseStream.Position = 0;
                        List<string> strList = new List<string>();
                        string line;
                        bool inSkill = false;

                        //run though each line in the file
                        while ((line = reader.ReadLine()) != null)
                        {
                            //if some line has the select skill keyword
                            if(line == SelectedSkill)
                            {
                                //you are now in the skill data group
                                inSkill = true;
                            }
                            //if you are in the skill data group
                            if(inSkill)
                            {
                                //and the line is empty
                                if(line == "")
                                {
                                    //you are now out of the skill group
                                    inSkill = false;
                                }
                            }
                            //if you're not in the skill data group, add the line to the list of strings for re-writing later.
                            else
                            {
                                strList.Add(line);
                            }
                        }

                        //program is now done reading in the lines not to be overridden
                        reader.Close();

                        //now re-write the lines not to be overridden
                        using (var writer = new StreamWriter(Path))
                        {
                            foreach (var item in strList)
                            {
                                writer.WriteLine(item);
                            }
                            //and finally write the selected skill keyword at the bottom of the file.
                            writer.WriteLine(SelectedSkill);
                        }
                    }
                }
            }
        }

        private void addTierButton_Click(object sender, EventArgs e)
        {
            //check for invalid values
            bool close = false;
            try
            {
                double num = double.Parse(tierXP.Text);
            }
            catch (Exception)
            {
                tierXP.Text = "Error: NaN";
                close = true;
            }
            try
            {
                double num = double.Parse(startTier.Text);
            }
            catch (Exception)
            {
                startTier.Text = "Error: NaN";
                close = true;
            }
            try
            {
                double num = double.Parse(endTier.Text);
            }
            catch (Exception)
            {
                endTier.Text = "Error: NaN";
                close = true;
            }
            if (close)
            {
                return;
            }

            //if the input is all valid and the function doesn't return, begin a new writer
            using (var writer = new StreamWriter(Path, true))
            {
                //if the selected skill requires other items
                if(EnableItemsNeeded)
                {
                    //generate the string to be later parsed and calculated
                    string line = "[" + tierName.Text + ", " + tierXP.Text + ", " + startTier.Text + ", " + endTier.Text;
                    string allItems = itemList.Text;
                    string[] requiredItems = allItems.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
                    
                    for (int i = 0; i < requiredItems.Length; i++)
                    {
                        line += ", " + requiredItems[i];
                    }
                    line += "]";
                    writer.WriteLine(line);
                }
                //if the selected skill does not require other items
                else
                    writer.WriteLine("[" + tierName.Text + ", " + tierXP.Text + ", " + startTier.Text + ", " + endTier.Text + "]");
            }
            //reset the ui
            tierName.Text = "";
            tierXP.Text = "";
            if (endTier.Text != "99") startTier.Text = endTier.Text;
            else startTier.Text = "";
            endTier.Text = "";
            itemList.Text = "";
            this.ProcessTabKey(true);
            this.ProcessTabKey(true);
            this.ProcessTabKey(true);
        }

        private void finishTiersButton_Click(object sender, EventArgs e)
        {
            //write a black line when finished
            using (var writer = new StreamWriter(Path, true))
            {
                writer.WriteLine();
            }
            this.Close();
        }
    }
}
