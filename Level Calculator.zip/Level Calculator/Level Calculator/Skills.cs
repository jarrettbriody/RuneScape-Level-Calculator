﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Level_Calculator
{
    class Skills
    {
        public int[] level = new int[100];
        public Dictionary<string, DictionaryValues> action = new Dictionary<string, DictionaryValues>();
        public string Path { get; set; }

        public Skills()
        {
            action.Clear();
            level[0] = 0;
            level[1] = 83;
            level[2] = 174;
            level[3] = 276;
            level[4] = 388;
            level[5] = 512;
            level[6] = 650;
            level[7] = 801;
            level[8] = 969;
            level[9] = 1154;
            level[10] = 1358;
            level[11] = 1584;
            level[12] = 1833;
            level[13] = 2107;
            level[14] = 2411;
            level[15] = 2746;
            level[16] = 3115;
            level[17] = 3523;
            level[18] = 3973;
            level[19] = 4470;
            level[20] = 5018;
            level[21] = 5624;
            level[22] = 6291;
            level[23] = 7028;
            level[24] = 7842;
            level[25] = 8740;
            level[26] = 9730;
            level[27] = 10824;
            level[28] = 12031;
            level[29] = 13363;
            level[30] = 14833;
            level[31] = 16456;
            level[32] = 18247;
            level[33] = 20224;
            level[34] = 22406;
            level[35] = 24815;
            level[36] = 27473;
            level[37] = 30408;
            level[38] = 33648;
            level[39] = 37224;
            level[40] = 41171;
            level[41] = 45529;
            level[42] = 50339;
            level[43] = 55649;
            level[44] = 61512;
            level[45] = 67983;
            level[46] = 75127;
            level[47] = 83014;
            level[48] = 91721;
            level[49] = 101333;
            level[50] = 111945;
            level[51] = 123660;
            level[52] = 136594;
            level[53] = 150872;
            level[54] = 166636;
            level[55] = 184040;
            level[56] = 203254;
            level[57] = 224466;
            level[58] = 247886;
            level[59] = 273742;
            level[60] = 302288;
            level[61] = 333804;
            level[62] = 368599;
            level[63] = 407015;
            level[64] = 449428;
            level[65] = 496254;
            level[66] = 547953;
            level[67] = 605032;
            level[68] = 668051;
            level[69] = 737627;
            level[70] = 814445;
            level[71] = 899257;
            level[72] = 992895;
            level[73] = 1096278;
            level[74] = 1210421;
            level[75] = 1336443;
            level[76] = 1475581;
            level[77] = 1629200;
            level[78] = 1798808;
            level[79] = 1986068;
            level[80] = 2192818;
            level[81] = 2421087;
            level[82] = 2673114;
            level[83] = 2951373;
            level[84] = 3258594;
            level[85] = 3597792;
            level[86] = 3972294;
            level[87] = 4385776;
            level[88] = 4842295;
            level[89] = 5346332;
            level[90] = 5902831;
            level[91] = 6517253;
            level[92] = 7195629;
            level[93] = 7944614;
            level[94] = 8771558;
            level[95] = 9684577;
            level[96] = 10692629;
            level[97] = 11805606;
            level[98] = 13034431;
            level[99] = 200000000;
        }

        public string Custom(string skill ,int cLevel, int cXP, int tLevel, bool otherItemsNeeded)
        {
            if (Path != null)
            {
                using (StreamReader reader = new StreamReader(Path, true))
                {
                    string line;
                    string[] splitLine = new string[4];
                    double xpValue = 1;
                    string[] _itemName = { };
                    string[] _itemsNeeded = { };
                    int[] __itemsNeeded = { };
                    int startTier = 1;
                    int endTier = 1;
                    Queue q = new Queue();
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line == skill)
                        {
                            while ((line = reader.ReadLine()) != "" && line != null)
                            {
                                if (line.Contains('[') && line.Contains(']'))
                                {
                                    line = line.Trim(new char[] { '[', ']', ' ' });
                                    splitLine = line.Split(',');
                                    try
                                    {
                                        xpValue = double.Parse(splitLine[1]);
                                        startTier = int.Parse(splitLine[2]);
                                        endTier = int.Parse(splitLine[3]);
                                        if (splitLine.Length > 4)
                                        {
                                            for (int i = 4; i < splitLine.Length; i++)
                                            {
                                                string[] otherItemsNeededSplitLine = splitLine[i].Split('=');
                                                int numberOfItemNeeded = Convert.ToInt32(otherItemsNeededSplitLine[1]);
                                                q.Enqueue(new ItemNeeded { Name = otherItemsNeededSplitLine[0], Number = numberOfItemNeeded });
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                    }
                                    action.Add(splitLine[0], new DictionaryValues
                                    {
                                        XpVal = xpValue,
                                        Start = startTier,
                                        End = endTier,
                                        Items = q
                                    });
                                    q = new Level_Calculator.Queue();
                                }
                            }
                        }
                    }
                }
                foreach (var item in action)
                {
                    Console.WriteLine(item);
                }

                double deficit = level[tLevel - 1] - cXP;
                double tempDeficit;
                double numOfActions;
                int numOfItems;
                int endLevel;
                int[] itemsNeeded;
                string[] itemNames;

                string returnStr = "Your experience deficit is " + deficit + " XP.\r\n\r\n";
                foreach (var item in action)
                {
                    if (cLevel < tLevel)
                    {
                        if (tLevel >= action[item.Key].End)
                        {
                            endLevel = action[item.Key].End;
                        }
                        else
                        {
                            endLevel = tLevel;
                        }
                        tempDeficit = level[endLevel - 1] - cXP;
                        numOfActions = Math.Ceiling(tempDeficit / action[item.Key].XpVal);

                        switch (skill)
                        {
                            case "Agility":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " laps at " + item.Key + " are required.\r\n";
                                break;
                            case "Attack":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + "Use a(n) " + item.Key + ".\r\n";
                                break;
                            case "Construction":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Cooking":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Crafting":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Defence":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + "Use a(n) " + item.Key + ".\r\n";
                                break;
                            case "Farming":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Firemaking":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Fishing":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Fletching":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Herblore":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Hitpoints":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + "Use a(n) " + item.Key + ".\r\n";
                                break;
                            case "Hunter":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Magic":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Mining":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Prayer":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Ranged":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + "Use a(n) " + item.Key + ".\r\n";
                                break;
                            case "Runecraft":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Slayer":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + "Use " + item.Key + ".\r\n";
                                break;
                            case "Smithing":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Strength":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + "Use a(n) " + item.Key + ".\r\n";
                                break;
                            case "Thieving":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            case "Woodcutting":
                                returnStr += "To get from level " + cLevel + " to level " + endLevel + ": " + numOfActions + " " + item.Key + "(s) at " + action[item.Key].XpVal + " XP per action are required.\r\n";
                                break;
                            default:
                                break;
                        }
                        if (otherItemsNeeded)
                        {
                            returnStr += "Items Needed:\r\n";
                            ItemNeeded currentItem;

                            while (action[item.Key].Items.IsEmpty() == false)
                            {
                                currentItem = action[item.Key].Items.Dequeue();
                                currentItem.Name = currentItem.Name.Trim(' ');
                                numOfItems = (int)numOfActions * currentItem.Number;
                                returnStr += currentItem.Name + " : " + numOfItems + "\r\n";
                            }
                            returnStr += "\r\n";
                        }
                        else
                            returnStr += "\r\n";
                        //returnStr += "To get from level " + cLevel + " to level " + action[item.Key].end + ": " + numOfActions + " " + item.Key + " at " + action[item.Key].xpVal + " XP per action.\r\n\r\n";
                        cLevel = endLevel;
                        cXP += (int)(numOfActions * action[item.Key].XpVal);
                    }
                }
                return returnStr;
            }
            return "";
        }
    }
}
