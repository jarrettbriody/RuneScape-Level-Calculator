﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Collections;
using System.IO;

namespace Level_Calculator
{
    public partial class PresetCheck : Form
    {
        public bool ExistingPreset { get; set; }
        public string PresetName { get; set; }
        string[] files;
        string fileName;
        public PresetCheck()
        {
            InitializeComponent();
            files = Directory.GetFiles("..\\presets\\");
            foreach (var item in files)
            {
                fileName = Path.GetFileName(item);
                fileName = fileName.Replace(".txt", "");
                presetDropDown.Items.Add(fileName);
            }
        }

        private void continueButton_Click(object sender, EventArgs e)
        {
            /*if(newPresetName.Text != "" && newPresetName.Text != "---")//&& (presetDropDown.Text == "" || presetDropDown.Text == "---"))
            {
                ExistingPreset = false;
                PresetName = "..\\presets\\" + newPresetName.Text + ".txt";
                this.Close();
            }*/
            if(presetDropDown.Text != "" && presetDropDown.Text != "---")
            {
                ExistingPreset = true;
                PresetName = "..\\presets\\" + presetDropDown.Text + ".txt";
                this.Close();
            }
        }

        private void newPresetButton_Click(object sender, EventArgs e)
        {

        }

        private void editPresetButton_Click(object sender, EventArgs e)
        {

        }
    }
}
